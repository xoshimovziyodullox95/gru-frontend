import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useAuth } from '../context/AuthContext';
import { getUserProfile } from '../services/user';
import { getUnreadCount as getNotifUnreadCount } from '../services/notifications';
import { getUnreadCount as getChatUnreadCount } from '../services/chat';
import {
  ShoppingCart, MessageCircle, LogOut, Menu, X,
  User, PlusCircle, Bell,
  LayoutDashboard
} from 'lucide-react';
import ThemeToggle from '../common/ThemeToggle';
import '../../styles/navbar.css';

// ==================== ASOSIY NAVBAR ====================
export default function Navbar() {
  const { t } = useTranslation(); // 🔥 tarjima funksiyasi
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [profileAvatar, setProfileAvatar] = useState('');
  const [activeTab, setActiveTab] = useState('business');
  const [chatUnreadCount, setChatUnreadCount] = useState(0);
  const [notifUnreadCount, setNotifUnreadCount] = useState(0);

  const role = user?.user_metadata?.role || 'user';
  const userName = user?.user_metadata?.full_name || user?.fullName || 'User';

  useEffect(() => {
    if (!user) return;
    getUserProfile()
      .then(res => setProfileAvatar(res.data.avatar_url || ''))
      .catch(() => {});
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const fetchUnread = () => {
      getChatUnreadCount()
        .then(res => setChatUnreadCount(res.data.count || 0))
        .catch(() => {});
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 10000);
    return () => clearInterval(interval);
  }, [user]);

  useEffect(() => {
    if (!user) return;
    const fetchNotifUnread = () => {
      getNotifUnreadCount()
        .then(res => setNotifUnreadCount(res.data.count || 0))
        .catch(() => {});
    };
    fetchNotifUnread();
    const interval = setInterval(fetchNotifUnread, 10000);
    return () => clearInterval(interval);
  }, [user]);

  const updateCartCount = () => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    setCartCount(cart.reduce((s, i) => s + i.quantity, 0));
  };

  useEffect(() => {
    updateCartCount();
    window.addEventListener('cartUpdated', updateCartCount);
    return () => window.removeEventListener('cartUpdated', updateCartCount);
  }, []);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);

  const handleLogout = async () => {
    await signOut();
    navigate('/');
  };

  const handleTabChange = (tab) => {
    setActiveTab(tab);
    navigate(tab === 'business' ? '/' : '/physic');
  };

  const avatarUrl = profileAvatar ||
    user?.user_metadata?.avatar_url ||
    `https://ui-avatars.com/api/?name=${encodeURIComponent(userName)}&background=00E5FF&color=fff&rounded=true&size=36`;

  if (loading) return <div className="gru-navbar-placeholder" />;

  return (
    <nav className={`gru-navbar ${scrolled ? 'gru-navbar-scrolled' : ''}`}>
      <div className="gru-navbar-container">
        <button className="gru-mobile-menu-btn" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
          {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        <div className="gru-navbar-left">
          <Link to="/home" className="gru-logo">G.R.U</Link>
          <div className="gru-tabs gru-tabs-desktop">
            <button
              className={`gru-tab ${activeTab === 'business' ? 'active' : ''}`}
              onClick={() => handleTabChange('business')}
            >
              {t('nav.business')}
            </button>
            <button
              className={`gru-tab ${activeTab === 'physic' ? 'active' : ''}`}
              onClick={() => handleTabChange('physic')}
            >
              {t('nav.physic')}
            </button>
          </div>
        </div>

        <div className={`gru-tabs-panel ${mobileMenuOpen ? 'gru-tabs-panel-open' : ''}`}>
          <button
            className={`gru-tab ${activeTab === 'business' ? 'active' : ''}`}
            onClick={() => { handleTabChange('business'); setMobileMenuOpen(false); }}
          >
            {t('nav.business')}
          </button>
          <button
            className={`gru-tab ${activeTab === 'physic' ? 'active' : ''}`}
            onClick={() => { handleTabChange('physic'); setMobileMenuOpen(false); }}
          >
            {t('nav.physic')}
          </button>
        </div>

        <div className="gru-navbar-right">
          {/* SAVAT */}
          <Link to="/cart" className="gru-nav-link" style={{ position: 'relative' }} title={t('nav.cart')}>
            <ShoppingCart size={20} />
            {cartCount > 0 && <span className="cart-badge">{cartCount}</span>}
          </Link>

          {/* CHAT */}
          <Link to="/chat" className="gru-nav-link" style={{ position: 'relative' }} title={t('nav.chat')}>
            <MessageCircle size={20} />
            {chatUnreadCount > 0 && (
              <span className="cart-badge" style={{ background: '#ff4444' }}>
                {chatUnreadCount}
              </span>
            )}
          </Link>

          {/* DASHBOARD */}
          {role === 'business' && (
            <Link to="/dashboard" className="gru-nav-link">
              <LayoutDashboard size={20} />
            </Link>
          )}

          {/* BILDIRISHNOMALAR */}
          {user && (
            <Link to="/notifications" className="gru-nav-link" style={{ position: 'relative' }} title={t('nav.notifications')}>
              <Bell size={20} />
              {notifUnreadCount > 0 && (
                <span className="cart-badge" style={{ background: '#ff4444' }}>
                  {notifUnreadCount}
                </span>
              )}
            </Link>
          )}

          {/* THEME TOGGLE */}
          <div className="gru-nav-link">
            <ThemeToggle />
          </div>

          {/* E'LON BERISH */}
          {user && (
            <Link
              to="/add-listing"
              className="gru-nav-link gru-add-listing-btn"
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '6px',
                background: '#00E5FF',
                color: '#0a0a0a',
                padding: '6px 14px',
                borderRadius: '20px',
                fontWeight: '600',
                transition: 'all 0.3s ease',
                textDecoration: 'none'
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#00BFFF';
                e.currentTarget.style.transform = 'scale(1.05)';
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#00E5FF';
                e.currentTarget.style.transform = 'scale(1)';
              }}
            >
              <PlusCircle size={18} />
              <span>{t('nav.addListing')}</span>
            </Link>
          )}

          {/* PROFIL AVATAR */}
          {user ? (
            <Link to="/profile" className="gru-avatar-btn" style={{ marginLeft: '4px' }}>
              <img src={avatarUrl} alt="Avatar" className="gru-avatar-img" />
            </Link>
          ) : (
            <Link to="/login" className="gru-nav-link">{t('nav.login')}</Link>
          )}
        </div>
      </div>
    </nav>
  );
}