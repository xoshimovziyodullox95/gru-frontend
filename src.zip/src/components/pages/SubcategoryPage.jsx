import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getRandomLocationsWithFallback } from '../services/locations';
import { getLevel2 } from '../services/categories';
import { MapPin, Calendar, Ruler, ArrowLeft, Building2, Tag, Crown } from 'lucide-react';
import UniversalCard from './UniversalCard';
import '../../styles/subcategory.css';

export default function SubcategoryPage() {
  const { level1, level2 } = useParams();
  const { user } = useAuth();
  const [locations, setLocations] = useState([]);
  const [subInfo, setSubInfo] = useState(null);
  const [loading, setLoading] = useState(true);

  // Premium holati
  const isPremium = user?.isPremium || user?.user_metadata?.isPremium || false;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const resSub = await getLevel2(level1);
        const found = resSub.data.find(item => (item.level2 || item.key) === decodeURIComponent(level2));
        setSubInfo(found || null);

        const resLocs = await getRandomLocationsWithFallback(level1, null, 10);
        setLocations(resLocs.data);
      } catch (err) {
        console.error('Failed to fetch locations:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [level1, level2]);

  if (loading) return <div className="sub-loading-spinner">Yuklanmoqda...</div>;

  const decodedLevel2 = decodeURIComponent(level2);

  return (
    <div className="sub-page">
      {/* HEADER */}
      <div className="sub-header">
        
<Link to={`/category/${encodeURIComponent(level1)}`} className="sub-back-btn">
          <ArrowLeft size={20} /> Orqaga
        </Link>
        <div className="sub-hero">
          {subInfo?.level2_image && (
            <img src={subInfo.level2_image} alt={decodedLevel2} className="sub-hero-img" />
          )}
          <div className="sub-hero-content">
            <h1 className="sub-title">{decodedLevel2}</h1>

            {/* Premium kontent – faqat premium user ko‘radi */}
            {isPremium ? (
              subInfo?.capex_min && subInfo?.capex_max && (
                <div className="sub-invest">
                  <Tag size={16} /> Investitsiya: ${subInfo.capex_min} – ${subInfo.capex_max}
                </div>
              )
            ) : (
              <div className="sub-premium-lock">
                <Crown size={18} />
                <span>Narx va hisob-kitoblar premium aʼzolar uchun</span>
                <Link to="/premium" className="sub-premium-link">⭐ Premium boʻlish</Link>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* LOCATIONS GRID — UniversalCard */}
      <div className="sub-container">
        {locations.length === 0 ? (
          <div className="sub-no-results">
            <Building2 size={48} />
            <p>Bu yo‘nalish bo‘yicha hozircha lokatsiyalar mavjud emas.</p>
            <span>Tez orada qo‘shiladi</span>
          </div>
        ) : (
          <div className="uc-grid">
            {locations.map(loc => {
              const locationId = loc._id || loc.id;
              if (!locationId) return null;

              return (
                <UniversalCard
                  key={locationId}
                  id={locationId}
                  type="location"
                  title={loc.title}
                  image={loc.images?.[0] || '/images/placeholder-location.jpg'}
                  price={loc.price_range}
                  link={`/location/${locationId}`}
                  createdAt={loc.createdAt}
                  meta={[
                    { icon: MapPin, text: loc.address || 'Manzil mavjud emas' },
                    { icon: Ruler, text: loc.sqm ? `${loc.sqm} m²` : '—' },
                  ]}
                />
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}