// src/components/pages/ServiceProviderDetailPage.jsx
import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useTranslation } from 'react-i18next'; // <-- qo'shildi
import {
  MapPin, Phone, ArrowLeft, ShieldCheck, Flame,
  Tag, Building2, Mail, Globe, MessageCircle,
  Star, User,
} from 'lucide-react';
import { getServiceProviderById } from '../services/serviceProviders';
import '../../styles/locationPage.css';
import '../../styles/serviceProviderDetail.css';
import CelebrityMotivationCard from '../common/CelebrityMotivationCard';

export default function ServiceProviderDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t } = useTranslation(); // <-- qo'shildi

  const [provider, setProvider] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPhone, setShowPhone] = useState(false);

  useEffect(() => {
    const load = async () => {
      try {
        setLoading(true);
        setError(null);
        const res = await getServiceProviderById(id);
        if (!res.data) {
          setError(t('serviceProvider.notFound'));
        } else {
          setProvider(res.data);
        }
      } catch (err) {
        console.error(err);
        setError(t('serviceProvider.loadError'));
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id, t]);

  const handleChat = () => {
    const targetId = provider?.userId?._id || provider?.userId;
    if (!targetId) {
      alert(t('serviceProvider.noOwnerInfo'));
      return;
    }
    navigate(`/chat?userId=${targetId}`);
  };

  if (loading) return <div className="StatusScreen">{t('serviceProvider.loading')}</div>;

  if (error || !provider) {
    return (
      <div className="StatusScreen Error">
        <h2>⚠️ {t('serviceProvider.error')}</h2>
        <p>{error || t('serviceProvider.notFound')}</p>
        <button onClick={() => navigate(-1)} className="BackActionBtn">
          <ArrowLeft size={16} /> {t('serviceProvider.back')}
        </button>
      </div>
    );
  }

  const images = provider.media?.length
    ? provider.media
    : [provider.image || '/images/service-providers/default.jpg'];

  // Badge matnlarini tarjima qilish
  const getProviderTypeLabel = (type) => {
    if (type === 'business') return t('serviceProvider.badgeBusiness');
    if (type === 'individual') return t('serviceProvider.badgeIndividual');
    return type || '';
  };

  return (
    <div className="LocationPageWrapper">
      <div className="MainViewport">
        <button className="BackActionBtn" onClick={() => navigate(-1)}>
          <ArrowLeft size={16} /> {t('serviceProvider.back')}
        </button>

        {/* ===== GALEREYA ===== */}
        <div className="image-gallery">
          <div className="image-gallery-main-wrap">
            <img
              src={images[0]}
              alt={provider.name}
              className="image-gallery-main"
              onError={(e) => { e.target.onerror = null; e.target.src = '/images/placeholder.jpg'; }}
            />
          </div>
          {images.length > 1 && (
            <div className="image-gallery-thumbs">
              {images.map((img, idx) => (
                <button key={idx} className={`gallery-thumb ${idx === 0 ? 'active' : ''}`}>
                  <img src={img} alt={`thumb-${idx}`} onError={(e) => { e.target.onerror = null; e.target.src = '/images/placeholder.jpg'; }} />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ===== ASOSIY GRID ===== */}
        <div className="LayoutGrid">
          {/* CHAP USTUN */}
          <div className="InformationContent">
            <div className="DetailsModule">
              <h2 className="ModuleHeading">{provider.name}</h2>

              <div className="location-meta">
                {provider.is_top && (
                  <span className="meta-badge"><Flame size={14} /> {t('serviceProvider.badgeTop')}</span>
                )}
                {provider.is_verified && (
                  <span className="meta-badge"><ShieldCheck size={14} /> {t('serviceProvider.badgeVerified')}</span>
                )}
                {provider.provider_type && (
                  <span className="meta-badge">
                    <User size={14} />
                    {getProviderTypeLabel(provider.provider_type)}
                  </span>
                )}
              </div>

              <p className="ModuleText">{provider.description || t('serviceProvider.defaultDescription')}</p>

              <div className="detail-grid">
                {provider.company && (
                  <div className="detail-item">
                    <span className="detail-icon"><Building2 size={16} /></span>
                    <div className="detail-text">
                      <span className="detail-label">{t('serviceProvider.company')}</span>
                      <strong>{provider.company}</strong>
                    </div>
                  </div>
                )}
                {provider.speciality && (
                  <div className="detail-item">
                    <span className="detail-icon"><Tag size={16} /></span>
                    <div className="detail-text">
                      <span className="detail-label">{t('serviceProvider.speciality')}</span>
                      <strong>{provider.speciality}</strong>
                    </div>
                  </div>
                )}
                {provider.price_range && (
                  <div className="detail-item">
                    <span className="detail-icon"><Star size={16} /></span>
                    <div className="detail-text">
                      <span className="detail-label">{t('serviceProvider.priceRange')}</span>
                      <strong>{provider.price_range}</strong>
                    </div>
                  </div>
                )}
                {typeof provider.rating === 'number' && (
                  <div className="detail-item">
                    <span className="detail-icon"><Star size={16} /></span>
                    <div className="detail-text">
                      <span className="detail-label">{t('serviceProvider.rating')}</span>
                      <strong>{provider.rating}</strong>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <CelebrityMotivationCard category={provider.level1} />

            {provider.userId && (
              <div className="user-info-card">
                <h3 className="ModuleHeading"><User size={18} /> {t('serviceProvider.owner')}</h3>
                <div className="user-info">
                  <img
                    src={
                      provider.userId.avatar_url ||
                      `https://ui-avatars.com/api/?name=${encodeURIComponent(provider.userId.full_name || 'U')}&background=00E5FF&color=fff&rounded=true&size=60`
                    }
                    alt={provider.userId.full_name}
                    className="user-avatar"
                    onError={(e) => e.target.src = '/images/placeholder.jpg'}
                  />
                  <div className="user-details">
                    <p><strong>{provider.userId.full_name || t('serviceProvider.fullName')}</strong></p>
                    {provider.userId.email && <p className="user-email">{provider.userId.email}</p>}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* O‘NG USTUN */}
          <div className="ActionSidebar">
            <div className="ContactSurface">
              <h3 className="CardSmallTitle">{t('serviceProvider.contactTitle')}</h3>

              {provider.email && (
                <div className="AddressLine"><Mail size={15} /> {provider.email}</div>
              )}
              {provider.website && (
                <div className="AddressLine">
                  <Globe size={15} />
                  <a href={provider.website} target="_blank" rel="noopener noreferrer">{provider.website}</a>
                </div>
              )}

              {!showPhone ? (
                <button className="RevealPhoneBtn" onClick={() => setShowPhone(true)}>
                  <Phone size={16} /> {t('serviceProvider.showPhone')}
                </button>
              ) : (
                <a href={`tel:${provider.phone}`} className="DirectPhoneLink">{provider.phone}</a>
              )}
            </div>

            <div className="chat-with-owner">
              <button onClick={handleChat} className="chat-owner-btn">
                <MessageCircle size={18} /> {t('serviceProvider.chatWithOwner')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}