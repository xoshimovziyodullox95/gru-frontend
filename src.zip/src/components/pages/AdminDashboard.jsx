import { useAuth } from '../context/AuthContext';
import { Navigate } from 'react-router-dom';

function AdminDashboard() {
  const { user } = useAuth();
  if (user?.email !== 'xoshimovabdullox95@gmail.com') return <Navigate to="/" />;
  return <div className="text-white p-10">👑 Admin panel</div>;
}
export default AdminDashboard;